package com.example.appboard;

public class ListViewItem {

    // DTO 역할
    // 생성자

    private String Icon;
    private String Title;
    private String Desc;

    public String getIcon() {
        return Icon;
    }

    public void setIcon(String icon) {
        Icon = icon;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String desc) {
        Desc = desc;
    }


}
